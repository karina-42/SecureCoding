// Edited by Angela Karina Vegega Ortiz
// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	const std::string account_number = "CharlieBrown42";
	char user_input[20]; 
	std::cout << "Enter a value: ";

	// Changed cin to cin.getline() so that it only accepts 19 chars (along with the null terminator) from the user using sizeof(user_input)
	if (std::cin.getline(user_input, sizeof(user_input))) { //If the size of the input is acceptable, display it and the account number
		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}
	else { // If the input is too long, clear and reset the buffer, and display a message to the user that 
		// they have entered too much data, without showing the account number
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::cout << "You have entered too many characters" << std::endl;
	}


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
