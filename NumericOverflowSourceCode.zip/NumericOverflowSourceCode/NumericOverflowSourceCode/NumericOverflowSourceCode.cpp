// Code edited by Angela Karina Vegega Ortiz
// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Added logic to check if the operation would lead to an overflow before performing the operation
        // If increment is greater than 0, and the result of subtracting increment from the upper limit
        // of the data type is less than result, the addition of result and increment will lead to an overflow.
        // For extra safety, there is also a check for adding two negatives. If increment is less than 0, and 
        // the result of subtracting increment from the lower limit of the data type is greater than result,
        // the operation will lead to an overflow. In both cases, the code will throw an exception to be caught 
        // in the test_overflow function
        if (((increment > 0) && (result > (std::numeric_limits<T>::max() - increment))) ||
            ((increment < 0) && (result < (std::numeric_limits<T>::lowest() - increment)))) {
            throw std::overflow_error("Overflow detected!");
        }
        else {
            result += increment;
        }
        
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;
    
    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Implemented a similar conditional as in the add_numberes function to verify 
        // before the computation that it will not result in an underflow. If the decrement is 
        // greater than 0 and the addition of the lowest limit of the data type and the decrement 
        // is greater than the current result, there will be an overflow. Similarly, if the decrement
        // is less than 0 and the maximum possible number of the data type added to the decrement is
        // less than the result, an underflow will happen. In either case, the code throws an underflow
        // error to be caught in the test_underflow function.
        if ((decrement > 0 && result < std::numeric_limits<T>::lowest() + decrement) ||
            (decrement < 0 && result > std::numeric_limits<T>::max() + decrement)) {
            throw std::underflow_error("Underflow detected!");
        }
        else {
            result -= decrement;
        }
        
    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Added a try/catch block to try the add_numbers function. If an error is thrown, it catches it and 
    // prints it to the console
    try {
        std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
        T result = add_numbers<T>(start, increment, steps);
        std::cout << +result << std::endl;

        std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
        result = add_numbers<T>(start, increment, steps + 1);
        std::cout << +result << std::endl;
    }
    catch (std::overflow_error const& ex) {
        std::cout << ex.what() << std::endl;
    }
    
}

template <typename T>
void test_underflow()
{
     // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Added a try/catch block to try the subtract_numbers function and catch the underflow error when it is thrown
    try {
        // Corrected Overflow typo to Underflow
        std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
        auto result = subtract_numbers<T>(start, decrement, steps);
        std::cout << +result << std::endl;

        // Corrected overflow typo to Underflow.
        // Adjusted the steps to produce the expected underflow
        std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps * 2) + 1 << ") = ";
        result = subtract_numbers<T>(start, decrement, (steps * 2) + 1);
        std::cout << +result << std::endl;
    }
    catch (std::underflow_error const& ex) {
        std::cout << ex.what() << std::endl;
    }

}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    // Corrected Undeflow typo to Underflow
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu